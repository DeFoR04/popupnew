document.getElementById("analyzeBtn").addEventListener("click", () => {
  const text = document.getElementById("inputText").value.trim();
  const resultBox = document.getElementById("resultBox");
  const resultText = document.getElementById("resultText");
  const confidenceText = document.getElementById("confidence");

  if (!text) {
    resultText.textContent = "Введите текст для анализа.";
    confidenceText.textContent = "";
    resultBox.classList.remove("hidden");
    return;
  }

  resultText.textContent = "Анализируем...";
  confidenceText.textContent = "";
  resultBox.classList.remove("hidden");

  fetch("http://127.0.0.1:5000/predict_json", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text })
  })
  .then(response => response.json())
  .then(data => {
    resultText.textContent = `Результат: ${data.prediction === "FAKE" ? "⚠️ Фейк" : "✅ Правдоподобно"}`;
    confidenceText.textContent = `Уверенность: ${data.confidence}%`;
  })
  .catch(error => {
    resultText.textContent = "Ошибка при подключении к API.";
    confidenceText.textContent = "";
    console.error("Ошибка:", error);
  });
});
